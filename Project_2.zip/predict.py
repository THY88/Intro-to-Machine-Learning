import argparse
from utils import (process_image, predict, load_model)
from PIL import Image
import numpy as np
import json

parser = argparse.ArgumentParser(description='Run model prediction!')
parser.add_argument('path', type=str)
parser.add_argument('model', type=str)
parser.add_argument('--top_k', default = 1, type=int, help='an integer for top number of classes')
parser.add_argument('--category_names', default = "./label_map.json", type=str, help='directory path for the label mapping file')

args = parser.parse_args()


with open(args.category_names, 'r') as f:
    class_names = json.load(f)

# Loading the model
model_file_path = f'./{args.model}'
loaded_model = load_model(model_file_path)

# Selecting image
image_path = args.path
im = Image.open(image_path)
test_image = np.asarray(im)

# Processing Image
processed_test_image = process_image(test_image)

# Predicting
image, k, classes = predict(processed_test_image, loaded_model, args.top_k)
label_names = [class_names[str(i+1)] for i in classes]

# Output layer
print(f"The top {args.top_k} predicted classes are {label_names} and their probabilites are {k}") 
 