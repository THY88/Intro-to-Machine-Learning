import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_hub as hub
import warnings
import time
import logging
from tensorflow.keras import regularizers
from PIL import Image

    
def process_image(image, image_size=224):
    image = tf.cast(image, tf.float32)
    image = tf.image.resize(image, (image_size, image_size))
    image /= 255
    return image


def predict(processed_test_image, model, top_k):
    proba_result = model.predict(np.expand_dims(processed_test_image, axis=0))[0]
    top_k_proba_list = sorted(proba_result, reverse=True)[:top_k]
    classes = []
    for results in top_k_proba_list:
        classes.append(np.where(proba_result == results)[0][0])
    return processed_test_image, top_k_proba_list, classes

def load_model(model_filepath):
    URL = "https://tfhub.dev/google/tf2-preview/mobilenet_v2/feature_vector/4"
    prebuild_layer = hub.KerasLayer(URL, input_shape=(224, 224, 3), trainable = False)
    loaded_model = tf.keras.models.load_model(model_filepath, custom_objects={'KerasLayer':prebuild_layer}, compile=False)
    return loaded_model